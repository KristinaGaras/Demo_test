<?php
session_start();
include 'config.php';

if (!isset($_SESSION['id_user']) || $_SESSION['username'] != 'Admin') {
    header('Location: auth.php');
    exit();
}

$message = '';

// Изменение статуса и назначение мастера
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['change_status'])) {
    $id_request = (int)$_POST['id_request'];
    $new_status = mysqli_real_escape_string($conn, $_POST['new_status']);
    $assigned_master = isset($_POST['assigned_master']) ? mysqli_real_escape_string($conn, $_POST['assigned_master']) : '';
    
    $sql = "UPDATE requests SET status='$new_status'";
    if ($new_status == 'В работе' && !empty($assigned_master)) {
        $sql .= ", assigned_master='$assigned_master'";
    }
    $sql .= " WHERE id_request=$id_request";
    
    if (mysqli_query($conn, $sql)) {
        $message = '<div class="success">Статус заявки обновлён</div>';
    } else {
        $message = '<div class="error">Ошибка: ' . mysqli_error($conn) . '</div>';
    }
}

// Фильтрация по статусу
$status_filter = '';
if (isset($_GET['status']) && !empty($_GET['status'])) {
    $status_filter = "AND status='{$_GET['status']}'";
}

$sql = "SELECT r.*, u.username, u.full_name, u.email, u.phone 
        FROM requests r 
        JOIN user u ON r.id_user = u.id_user 
        WHERE 1 $status_filter 
        ORDER BY 
            CASE status 
                WHEN 'Новая' THEN 1 
                WHEN 'В работе' THEN 2 
                WHEN 'Готов к выдаче' THEN 3 
                WHEN 'Завершен' THEN 4 
            END,
            r.id_request DESC";

$requests = mysqli_query($conn, $sql);

// Статистика
$stats = mysqli_fetch_assoc(mysqli_query($conn, "SELECT 
    COUNT(*) as total,
    SUM(status='Новая') as new,
    SUM(status='В работе') as in_progress,
    SUM(status='Готов к выдаче') as ready,
    SUM(status='Завершен') as completed
    FROM requests"));
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Панель администратора - АвтоМастер</title>
    <link rel="stylesheet" href="./css/style.css">
</head>
<body>
    <header>
        <a href="index.php">Главная</a>
        <a href="admin.php">Админ-панель</a>
        <a href="logout.php">Выйти</a>
    </header>
    
    <div class="container">
        <h1>Панель администратора</h1>
        <p>Добро пожаловать, <?php echo $_SESSION['username']; ?>!</p>
        <?php echo $message; ?>
        
        <!-- Статистика -->
        <div class="stats-container">
            <div class="stat-card"><div class="stat-value"><?php echo $stats['total']; ?></div><div class="stat-label">Всего заявок</div></div>
            <div class="stat-card stat-new"><div class="stat-value"><?php echo $stats['new']; ?></div><div class="stat-label">Новые</div></div>
            <div class="stat-card stat-progress"><div class="stat-value"><?php echo $stats['in_progress']; ?></div><div class="stat-label">В работе</div></div>
            <div class="stat-card stat-ready"><div class="stat-value"><?php echo $stats['ready']; ?></div><div class="stat-label">Готов к выдаче</div></div>
            <div class="stat-card stat-completed"><div class="stat-value"><?php echo $stats['completed']; ?></div><div class="stat-label">Завершены</div></div>
        </div>
        
        <!-- Фильтр по статусу -->
        <form method="GET" class="filter-form">
            <select name="status">
                <option value="">Все статусы</option>
                <option value="Новая">Новая</option>
                <option value="В работе">В работе</option>
                <option value="Готов к выдаче">Готов к выдаче</option>
                <option value="Завершен">Завершен</option>
            </select>
            <input type="submit" value="Фильтровать">
            <a href="admin.php">Сбросить</a>
        </form>
        
        <!-- Таблица заявок -->
        <table>
            <thead>
                <tr>
                    <th>№</th>
                    <th>Клиент</th>
                    <th>Автомобиль</th>
                    <th>Услуга</th>
                    <th>Желаемая дата</th>
                    <th>Оплата</th>
                    <th>Статус</th>
                    <th>Мастер</th>
                    <th>Отзыв</th>
                    <th>Действие</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($r = mysqli_fetch_assoc($requests)): ?>
                    <tr>
                        <td><?php echo $r['id_request']; ?></td>
                        <td>
                            <strong><?php echo htmlspecialchars($r['username']); ?></strong><br>
                            <small><?php echo htmlspecialchars($r['full_name']); ?></small><br>
                            <small><?php echo htmlspecialchars($r['phone']); ?></small><br>
                            <small><?php echo htmlspecialchars($r['email']); ?></small>
                        </td>
                        <td><?php echo htmlspecialchars($r['car_brand']); ?></td>
                        <td><?php echo htmlspecialchars($r['service_type']); ?></td>
                        <td><?php echo date('d.m.Y', strtotime($r['desired_date'])); ?></td>
                        <td><?php echo htmlspecialchars($r['pay_method']); ?></td>
                        <td>
                            <?php 
                            $classes = [
                                'Новая' => 'status-new',
                                'В работе' => 'status-in-progress',
                                'Готов к выдаче' => 'status-ready',
                                'Завершен' => 'status-completed'
                            ];
                            $class = isset($classes[$r['status']]) ? $classes[$r['status']] : 'status-new';
                            echo "<span class='status-badge $class'>{$r['status']}</span>";
                            ?>
                        </td>
                        <td><?php echo htmlspecialchars($r['assigned_master'] ?: 'Не назначен'); ?></td>
                        <td><?php echo nl2br(htmlspecialchars($r['feedback'] ?: '—')); ?></td>
                        <td>
                            <form method="POST" style="display: flex; flex-direction: column; gap: 5px;">
                                <input type="hidden" name="id_request" value="<?php echo $r['id_request']; ?>">
                                <select name="new_status" required>
                                    <option value="Новая" <?php echo $r['status'] == 'Новая' ? 'selected' : ''; ?>>Новая</option>
                                    <option value="В работе" <?php echo $r['status'] == 'В работе' ? 'selected' : ''; ?>>В работе</option>
                                    <option value="Готов к выдаче" <?php echo $r['status'] == 'Готов к выдаче' ? 'selected' : ''; ?>>Готов к выдаче</option>
                                    <option value="Завершен" <?php echo $r['status'] == 'Завершен' ? 'selected' : ''; ?>>Завершен</option>
                                </select>
                                <input type="text" name="assigned_master" placeholder="ФИО мастера" value="<?php echo htmlspecialchars($r['assigned_master']); ?>">
                                <input type="submit" name="change_status" value="Обновить">
                            </form>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
    
    <script src="./js/script.js"></script>
</body>
</html>