<?php 
//параметры mysqli_connect: "хост","пользователь","пароль для пользователя","название базы данных"
$conn = mysqli_connect("localhost","e906513z_bd","123aS!","e906513z_bd");

//проверка соединения
if(!$conn){
    die("Ошибка подключения:".mysqli_connect_error());
}
?>