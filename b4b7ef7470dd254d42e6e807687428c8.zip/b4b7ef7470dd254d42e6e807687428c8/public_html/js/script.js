// Простой слайдер
let currentSlide = 0;
const slides = document.querySelectorAll('.slide');
const prevBtn = document.querySelector('.prev');
const nextBtn = document.querySelector('.next');

// Функция показа слайда
function showSlide(index) {
    // Зацикливание
    if (index < 0) index = slides.length - 1;
    if (index >= slides.length) index = 0;
    
    // Сдвигаем слайды
    document.querySelector('.slider').style.transform = `translateX(-${index * 100}%)`;
    currentSlide = index;
}

// Кнопки
if (prevBtn) {
    prevBtn.addEventListener('click', () => showSlide(currentSlide - 1));
}
if (nextBtn) {
    nextBtn.addEventListener('click', () => showSlide(currentSlide + 1));
}

// Автоматическая смена слайдов каждые 3 секунды
setInterval(() => showSlide(currentSlide + 1), 3000);

// Подсветка активного пункта меню
const currentPage = window.location.pathname.split('/').pop();
document.querySelectorAll('header a').forEach(link => {
    if (link.getAttribute('href') === currentPage) {
        link.style.backgroundColor = '#555';
        link.style.borderRadius = '3px';
    }
});

// Простое появление элементов
document.querySelectorAll('.service-card, .card').forEach((el, i) => {
    el.style.opacity = '0';
    setTimeout(() => {
        el.style.transition = 'opacity 0.5s';
        el.style.opacity = '1';
    }, i * 100);
});