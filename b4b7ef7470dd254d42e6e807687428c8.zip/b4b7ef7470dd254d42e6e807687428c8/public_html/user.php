<?php
session_start();
include 'config.php';

if (!isset($_SESSION['id_user'])) {
    header('Location: auth.php');
    exit();
}

$id_user = $_SESSION['id_user'];
$message = '';

// Добавление отзыва
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_feedback'])) {
    $id_request = (int)$_POST['id_request'];
    $feedback = mysqli_real_escape_string($conn, $_POST['feedback']);
    
    $check = mysqli_query($conn, "SELECT * FROM requests WHERE id_request=$id_request AND id_user=$id_user AND status='Завершен'");
    
    if (mysqli_num_rows($check) > 0) {
        mysqli_query($conn, "UPDATE requests SET feedback='$feedback' WHERE id_request=$id_request");
        $message = '<div class="success">Спасибо за ваш отзыв!</div>';
    } else {
        $message = '<div class="error">Отзыв можно оставить только для завершённых заявок</div>';
    }
}

$requests = mysqli_query($conn, "SELECT * FROM requests WHERE id_user=$id_user ORDER BY id_request DESC");
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Мои заявки - АвтоМастер</title>
    <link rel="stylesheet" href="./css/style.css">
</head>
<body>
    <header>
        <a href="index.php">Главная</a>
        <a href="user.php">Мои заявки</a>
        <a href="add_request.php">Новая заявка</a>
        <a href="logout.php">Выйти</a>
    </header>
    
    <div class="container">
        <h1>Добро пожаловать, <?php echo $_SESSION['username']; ?>!</h1>
        <?php echo $message; ?>
        
        <div class="new-request-card">
            <h2>Нужен ремонт или обслуживание?</h2>
            <a href="add_request.php">➕ Создать новую заявку</a>
        </div>
        
        <h2>Мои заявки на ремонт</h2>
        
        <?php if (mysqli_num_rows($requests) > 0): ?>
            <div class="services-grid">
                <?php while ($r = mysqli_fetch_assoc($requests)): ?>
                    <div class="service-card">
                        <div class="card-header">
                            <h3><?php echo $r['car_brand']; ?> - <?php echo $r['service_type']; ?></h3>
                            <span class="card-number">№ <?php echo $r['id_request']; ?></span>
                        </div>
                        <div class="card-body">
                            <div>📅 Желаемая дата: <?php echo date('d.m.Y', strtotime($r['desired_date'])); ?></div>
                            <div>💰 Оплата: <?php echo $r['pay_method']; ?></div>
                            <div>
                                <?php 
                                $classes = ['Новая' => 'status-new', 'В работе' => 'status-in-progress', 'Готов к выдаче' => 'status-ready', 'Завершен' => 'status-completed'];
                                $status_class = isset($classes[$r['status']]) ? $classes[$r['status']] : 'status-new';
                                echo "<span class='status-badge $status_class'>{$r['status']}</span>";
                                ?>
                            </div>
                            <?php if ($r['assigned_master']): ?>
                                <div>🔧 Мастер: <?php echo htmlspecialchars($r['assigned_master']); ?></div>
                            <?php endif; ?>
                            <?php if ($r['feedback']): ?>
                                <div>⭐ Отзыв: <?php echo nl2br(htmlspecialchars($r['feedback'])); ?></div>
                            <?php endif; ?>
                        </div>
                        
                        <?php if ($r['status'] == 'Завершен' && empty($r['feedback'])): ?>
                            <div class="card-footer">
                                <button onclick="showFeedbackForm(<?php echo $r['id_request']; ?>)" class="button-small">📝 Оставить отзыв</button>
                                <div id="feedback-form-<?php echo $r['id_request']; ?>" style="display:none; margin-top: 10px;">
                                    <form method="POST">
                                        <input type="hidden" name="id_request" value="<?php echo $r['id_request']; ?>">
                                        <textarea name="feedback" placeholder="Расскажите о качестве обслуживания..." required></textarea>
                                        <input type="submit" name="add_feedback" value="Отправить отзыв">
                                        <button type="button" onclick="hideFeedbackForm(<?php echo $r['id_request']; ?>)">Отмена</button>
                                    </form>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endwhile; ?>
            </div>
        <?php else: ?>
            <div class="empty-state">
                <p>У вас пока нет заявок</p>
                <a href="add_request.php">Создать первую заявку</a>
            </div>
        <?php endif; ?>
    </div>
    
    <script>
        function showFeedbackForm(id) {
            document.getElementById('feedback-form-' + id).style.display = 'block';
        }
        function hideFeedbackForm(id) {
            document.getElementById('feedback-form-' + id).style.display = 'none';
        }
    </script>
    <script src="./js/script.js"></script>
</body>
</html>