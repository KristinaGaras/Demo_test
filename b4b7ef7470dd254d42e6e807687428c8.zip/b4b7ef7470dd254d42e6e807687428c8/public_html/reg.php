<?php
include 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['reg'])) {
    $username = trim($_POST['username']);
    $password = $_POST['password'];
    $full_name = trim($_POST['full_name']);
    $phone = trim($_POST['phone']);
    $email = trim($_POST['email']);
    
    $errors = [];
    
    // Проверка на пустоту
    if (empty($username) || empty($password) || empty($full_name) || empty($phone) || empty($email)) {
        $errors[] = "Все поля обязательны для заполнения";
    }
    
    // Логин: латиница и цифры, не менее 6 символов
    if (!preg_match("/^[A-Za-z0-9]{6,}$/", $username)) {
        $errors[] = "Логин должен содержать минимум 6 символов (латиница и цифры)";
    }
    
    // Пароль: минимум 8 символов
    if (strlen($password) < 8) {
        $errors[] = "Пароль должен быть не менее 8 символов";
    }
    
    // ФИО: кириллица и пробелы
    if (!preg_match("/^[А-Яа-яЁё\s]+$/u", $full_name)) {
        $errors[] = "ФИО должно содержать только кириллицу и пробелы";
    }
    
    // Телефон: формат 8(XXX)XXX-XX-XX
    if (!preg_match("/^8\(\d{3}\)\d{3}-\d{2}-\d{2}$/", $phone)) {
        $errors[] = "Телефон должен быть в формате 8(XXX)XXX-XX-XX";
    }
    
    // Email: валидный формат
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Введите корректный email";
    }
    
    // Проверка уникальности логина
    $check = mysqli_query($conn, "SELECT id_user FROM user WHERE username = '$username'");
    if (mysqli_num_rows($check) > 0) {
        $errors[] = "Пользователь с таким логином уже существует";
    }
    
    if (empty($errors)) {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $sql = "INSERT INTO user (username, password, full_name, phone, email, role_id) 
                VALUES ('$username', '$hash', '$full_name', '$phone', '$email', 2)";
        
        if (mysqli_query($conn, $sql)) {
            header('Location: auth.php');
            exit();
        } else {
            $errors[] = "Ошибка при регистрации: " . mysqli_error($conn);
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Регистрация - АвтоМастер</title>
    <link rel="stylesheet" href="./css/style.css">
</head>
<body>
    <header>
        <a href="index.php">Главная</a>
        <a href="auth.php">Вход</a>
        <a href="reg.php">Регистрация</a>
    </header>
    
    <div class="container">
        <h1>Регистрация на портале "АвтоМастер"</h1>
        
        <form method="POST" action="reg.php">
            <input type="text" name="username" placeholder="Логин (латиница, от 6 символов)" required>
            <input type="password" name="password" placeholder="Пароль (минимум 8 символов)" required>
            <input type="text" name="full_name" placeholder="ФИО (кириллица)" required>
            <input type="text" name="phone" placeholder="Телефон (формат: 8(XXX)XXX-XX-XX)" required>
            <input type="email" name="email" placeholder="Email" required>
            <input type="submit" name="reg" value="Создать пользователя">
            
            <?php if (!empty($errors)): ?>
                <?php foreach ($errors as $error): ?>
                    <div class="error"><?php echo $error; ?></div>
                <?php endforeach; ?>
            <?php endif; ?>
        </form>
        
        <p style="text-align: center;">
            <a href="auth.php">Уже есть аккаунт? Войти</a>
        </p>
    </div>
    
    <script src="./js/script.js"></script>
</body>
</html>