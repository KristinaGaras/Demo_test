<?php
session_start();
include 'config.php';
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>АвтоМастер - Запись на ремонт</title>
    <link rel="stylesheet" href="./css/style.css">
</head>
<body>
    <header>
        <a href="index.php">Главная</a>
        <?php if (isset($_SESSION['id_user'])): ?>
            <a href="user.php">Мои заявки</a>
            <a href="add_request.php">Новая заявка</a>
            <?php if ($_SESSION['role_id'] == 1): ?>
                <a href="admin.php">Админ-панель</a>
            <?php endif; ?>
            <a href="logout.php">Выйти</a>
        <?php else: ?>
            <a href="auth.php">Вход</a>
            <a href="reg.php">Регистрация</a>
        <?php endif; ?>
    </header>
    
    <div class="container">
        <h1>АвтоМастер</h1>
        <p class="subtitle">Профессиональный ремонт и обслуживание автомобилей</p>
        
        <!-- Слайдер с изображениями работ -->
        <div class="slider-container">
            <div class="slider">
                <img src="./images/car_service_1.jpg" alt="Кузовной ремонт" class="slide">
                <img src="./images/car_service_2.jpg" alt="Диагностика" class="slide">
                <img src="./images/car_service_3.jpg" alt="Шиномонтаж" class="slide">
                <img src="./images/car_service_4.jpg" alt="Ремонт двигателя" class="slide">
            </div>
            <button class="slider-btn prev">❮</button>
            <button class="slider-btn next">❯</button>
        </div>
        
        <!-- Услуги -->
        <div class="services-preview">
            <h2>Наши услуги</h2>
            <div class="service-icons">
                <div class="service-icon">
                    <span>Ремонт двигателя</span>
                </div>
                <div class="service-icon">
                    <span>Шиномонтаж</span>
                </div>
                <div class="service-icon">
                    <span>Кузовной ремонт</span>
                </div>
                <div class="service-icon">
                    <span>Диагностика</span>
                </div>
            </div>
        </div>
        
        <div class="cta-section">
            <h3>Нужен ремонт?</h3>
            <?php if (isset($_SESSION['id_user'])): ?>
                <a href="add_request.php" class="cta-button">Оставить заявку</a>
            <?php else: ?>
                <a href="reg.php" class="cta-button">Зарегистрироваться</a>
            <?php endif; ?>
        </div>
    </div>
    
    <script src="./js/script.js"></script>
</body>
</html>