<?php
session_start();
include 'config.php';

if (!isset($_SESSION['id_user'])) {
    header('Location: auth.php');
    exit();
}

$id_user = $_SESSION['id_user'];
$message = '';

$brands_result = mysqli_query($conn, "SELECT * FROM car_brands ORDER BY brand_name");
$services_result = mysqli_query($conn, "SELECT * FROM service_types ORDER BY service_name");
$payments_result = mysqli_query($conn, "SELECT * FROM payment_methods ORDER BY method_name");

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add'])) {
    $car_brand = mysqli_real_escape_string($conn, $_POST['car_brand']);
    $service_type = mysqli_real_escape_string($conn, $_POST['service_type']);
    $desired_date = mysqli_real_escape_string($conn, $_POST['desired_date']);
    $pay_method = mysqli_real_escape_string($conn, $_POST['pay_method']);
    
    if (empty($car_brand) || empty($service_type) || empty($desired_date) || empty($pay_method)) {
        $message = '<div class="error">Заполните все поля</div>';
    } else {
        $sql = "INSERT INTO requests (id_user, car_brand, service_type, desired_date, pay_method, status) 
                VALUES ($id_user, '$car_brand', '$service_type', '$desired_date', '$pay_method', 'Новая')";
        
        if (mysqli_query($conn, $sql)) {
            header('Location: user.php');
            exit();
        } else {
            $message = '<div class="error">Ошибка: ' . mysqli_error($conn) . '</div>';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Новая заявка - АвтоМастер</title>
    <link rel="stylesheet" href="./css/style.css">
</head>
<body>
    <header>
        <a href="index.php">Главная</a>
        <a href="user.php">Мои заявки</a>
        <a href="add_request.php">Новая заявка</a>
        <a href="logout.php">Выйти</a>
    </header>
    
    <div class="container">
        <h1>Оформление заявки на ремонт</h1>
        
        <?php echo $message; ?>
        
        <form method="POST" action="add_request.php">
            <select name="car_brand" required>
                <option value="">Выберите марку автомобиля</option>
                <?php while ($brand = mysqli_fetch_assoc($brands_result)): ?>
                    <option value="<?php echo $brand['brand_name']; ?>"><?php echo $brand['brand_name']; ?></option>
                <?php endwhile; ?>
            </select>
            
            <select name="service_type" required>
                <option value="">Выберите тип услуги</option>
                <?php while ($service = mysqli_fetch_assoc($services_result)): ?>
                    <option value="<?php echo $service['service_name']; ?>"><?php echo $service['service_name']; ?></option>
                <?php endwhile; ?>
            </select>
            
            <input type="text" name="desired_date" placeholder="Желаемая дата (ДД.ММ.ГГГГ)" required>
            
            <select name="pay_method" required>
                <option value="">Выберите способ оплаты</option>
                <?php while ($payment = mysqli_fetch_assoc($payments_result)): ?>
                    <option value="<?php echo $payment['method_name']; ?>"><?php echo $payment['method_name']; ?></option>
                <?php endwhile; ?>
            </select>
            
            <input type="submit" name="add" value="Отправить заявку">
        </form>
        
        <p style="text-align: center; margin-top: 20px;">
            <a href="user.php">← Назад к моим заявкам</a>
        </p>
    </div>
    
    <script src="./js/script.js"></script>
</body>
</html>