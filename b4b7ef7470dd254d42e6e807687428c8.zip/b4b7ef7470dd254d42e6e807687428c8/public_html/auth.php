<?php
session_start();
include 'config.php';

if (isset($_SESSION['id_user'])) {
    if ($_SESSION['role_id'] == 1) {
        header('Location: admin.php');
    } else {
        header('Location: user.php');
    }
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['auth'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];
    
    if (empty($username) || empty($password)) {
        $error = "Заполните все поля";
    } else {
        // Специальная проверка для администратора (по заданию: логин Admin, пароль AutoService)
        if ($username === 'Admin' && $password === 'AutoService') {
            $_SESSION['id_user'] = 999; 
            $_SESSION['username'] = 'Admin';
            $_SESSION['role_id'] = 1;
            header('Location: admin.php');
            exit();
        } else {
            $sql = "SELECT * FROM user WHERE username = ?";
            $stmt = mysqli_prepare($conn, $sql);
            mysqli_stmt_bind_param($stmt, "s", $username);
            mysqli_stmt_execute($stmt);
            $result = mysqli_stmt_get_result($stmt);
            
            if (mysqli_num_rows($result) > 0) {
                $user = mysqli_fetch_assoc($result);
                if (password_verify($password, $user['password'])) {
                    $_SESSION['id_user'] = $user['id_user'];
                    $_SESSION['username'] = $user['username'];
                    $_SESSION['role_id'] = $user['role_id'];
                    header('Location: user.php');
                    exit();
                } else {
                    $error = "Неверный пароль";
                }
            } else {
                $error = "Пользователь не найден";
            }
            mysqli_stmt_close($stmt);
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Авторизация - АвтоМастер</title>
    <link rel="stylesheet" href="./css/style.css">
</head>
<body>
    <header>
        <a href="index.php">Главная</a>
        <a href="auth.php">Вход</a>
        <a href="reg.php">Регистрация</a>
    </header>
    
    <div class="container">
        <h1>Авторизация</h1>
        
        <div class="login-form">
            <form method="POST" action="auth.php">
                <input type="text" name="username" placeholder="Логин" required>
                <input type="password" name="password" placeholder="Пароль" required>
                <input type="submit" name="auth" value="Войти">
            </form>
            
            <?php if (isset($error)): ?>
                <div class="error"><?php echo $error; ?></div>
            <?php endif; ?>
        </div>
        
        <div class="form-footer">
            <p>Нет аккаунта? <a href="reg.php">Зарегистрироваться</a></p>
        </div>
    </div>
    
    <script src="./js/script.js"></script>
</body>
</html>